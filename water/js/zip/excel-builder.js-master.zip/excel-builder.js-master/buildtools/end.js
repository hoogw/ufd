    root.ExcelBuilder = require('excel-builder');
})(window);