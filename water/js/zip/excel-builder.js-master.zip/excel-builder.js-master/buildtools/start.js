(function (root) {
    